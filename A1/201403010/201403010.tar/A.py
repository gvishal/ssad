import pacman_game

pacman_game.main()