-Part A My Pacman

A.py imports pacman_game and 
    pacman_game imports pacman_board


-Inheritance done via classes
-Polymorphism done via function overriding in child classes
-Modularity  
    -done using creating separate module for board
    -done using functions
-Encapsulation
    -done by combining data members and functions that work on it

-All Functionalities of the game have been implemented

-checkGhost() is defined as Ghost.check_ghost()
-collectCoin() is defined as Pacman.collect_coin()
-ghostPosititon() is defined as Ghost.ghost_position()
-checkWall() is defined as Board.check_wall()

*Bonus*
-Mulitple ghosts - 3 and more can be added!!!
-Diagnal ghost movement
-Single key-press movement
-Colored objects

-Part B My Commands

B.py imports commands.py

-Implemented ls, ls -l, mv, cp(and cp -r) and rm(and rm -r).
-Implemented dirstr
-Errors handled correctly

*Bonus*
-dirstr displays file size and last modified date
-Implemented pwd and mkdir