import commands

commands.main()