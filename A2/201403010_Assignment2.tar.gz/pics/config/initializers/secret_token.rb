# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Pics::Application.config.secret_token = '1a643b214585bc9a94389772bdc3e4cdf2e319bef110f621fc6e7b0982b3557fa0083b7c218d36c3efec3d782b51dbe7e1551feddbb6d8ebd5d46538e5b6b0cd'
