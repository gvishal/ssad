pics is the rails app

Images are in public/assets

And db used is sqlite so no dump file!